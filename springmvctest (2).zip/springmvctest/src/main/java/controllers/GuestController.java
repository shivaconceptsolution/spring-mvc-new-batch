package controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.scs.dao.Registration;
@Controller
public class GuestController {
	@RequestMapping("/home")
    public ModelAndView home()
    {
    	return new ModelAndView("home");
    }
	@RequestMapping("/login")
    public ModelAndView login(HttpServletRequest request)
    {
		Configuration cfg = new Configuration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session sess = sf.openSession();

		Query q = sess.createQuery("from Registration r where r.username=:a and r.password=:b");        
        q.setString("a",request.getParameter("txtname"));
        q.setString("b",request.getParameter("txtpass"));
        List lst = q.list();
        String res="";
		if(lst.size()>0)
		{
			res ="login success";
		}
		else
		{
			res = "login fail";
		}
		sess.close();
		return new ModelAndView("home","key",res);
		
    	
    }
	@RequestMapping("/about")
    public ModelAndView about()
    {
    	return new ModelAndView("about");
    }
	@RequestMapping("/reg")
    public ModelAndView reg(HttpServletRequest request)
    {
		Configuration cfg = new Configuration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session sess = sf.openSession();

		Transaction tx= sess.beginTransaction();
        Registration obj = new Registration();
        obj.setUsername(request.getParameter("txtname"));
        obj.setPassword(request.getParameter("txtpass"));
        obj.setEmail(request.getParameter("txtemail"));
        obj.setMobileno(request.getParameter("txtmobile"));
		sess.save(obj);

		tx.commit();

		sess.close();
    	return new ModelAndView("about","key","Reg successfully");
    }
	@RequestMapping("/services")
    public ModelAndView services()
    {
    	return new ModelAndView("services");
    }
	@RequestMapping("/gallery")
    public ModelAndView gallery()
    {
    	return new ModelAndView("gallery");
    }
	@RequestMapping("/contact")
    public ModelAndView contacts()
    {
    	return new ModelAndView("contact");
    }
	
}
